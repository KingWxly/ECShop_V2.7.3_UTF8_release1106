<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>ECTouch - 安装成功</title>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE">
<meta name="viewport" content="width=device-width"/>
<link rel="stylesheet" href="__ASSETS__/css/install.css"/>
</head>
<body>
<div class="blank68"></div>
<div class="m-install">
  <div class="install-head"> ECTouch - 安装成功 </div>
  <div class="install-model">
    <div class="m-form">
        <div class="install-button" style="position: relative;"> ECTouch安装成功！您可以<a href="__URL__/admin">进入后台管理</a>！<br><img src="{$mobile_qr}" width="320" height="320" /><br>恭喜你安装成功，想不想马上把你的移动商城分享给朋友圈，让更多朋友膜拜呢。<div class="bdsharebuttonbox" style="position: absolute;left: 50%;margin-left: -60px !important;"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a></div><br><br></div>
    </div>
  </div>
</div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"朋友们，我使用免费开源的ECTouch移动商城系统成功建立了自己的移动商城，商城网址：__URL__ ，欢迎参观访问。","bdMini":"2","bdMiniList":false,"bdUrl":"__URL__","bdPic":"http://ectouch.cn/data/assets/common/images/share.png","bdStyle":"0","bdSize":"16"},"share":{},"image":{"viewList":["tsina","qzone","tqq","renren","weixin"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["tsina","qzone","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
</body>
<!--Copyright © 2014 ectouch.cn. All Rights Reserved.-->
</html>